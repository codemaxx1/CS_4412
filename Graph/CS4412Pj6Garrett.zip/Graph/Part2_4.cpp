#include "Part2_4.h"

Part24::Part24()
{
}

Part24::~Part24()
{
}