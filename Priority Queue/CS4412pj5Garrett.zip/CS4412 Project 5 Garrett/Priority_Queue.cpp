#include "Priority_Queue.h"

Priority_Queue::Priority_Queue()
{
}

Priority_Queue::~Priority_Queue()
{
}

