#include "logging.h"

logging::logging()
{
}

logging::~logging()
{
}