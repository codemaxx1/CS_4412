#include "PrimsAlgorithm.h"

PrimsAlgorithm::PrimsAlgorithm()
{
}

PrimsAlgorithm::~PrimsAlgorithm()
{
}