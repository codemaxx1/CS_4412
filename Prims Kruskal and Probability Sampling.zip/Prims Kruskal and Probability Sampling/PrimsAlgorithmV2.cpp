#include "PrimsAlgorithmV2.h"

PrimsAlgorithmV2::PrimsAlgorithmV2()
{
}

PrimsAlgorithmV2::~PrimsAlgorithmV2()
{
}